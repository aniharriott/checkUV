package com.example.checkuv.ui.forecast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ForecastViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    private String UV;

    public ForecastViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("current UV: ");
    }

    public LiveData<String> getText() {
        return mText;
    }

    public void setmText(String string) {
        UV = string;
    }
}